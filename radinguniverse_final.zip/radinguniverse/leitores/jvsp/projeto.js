/*
const vavItems = document.querySelectorAll('.nav-item[data-target]');
const contentViews = document.querySelectorAll('content-view');

navItems.forEach(item => {
    item.addeventListener('click',() =>{

    }
}); 
*/
const navItems = document.querySelectorAll('.nav-item[data-target]');
const contentViews = document.querySelectorAll('.content-view');

navItems.forEach(item => {
    item.addEventListener('click', () => {
        // Remove classe ativa de todos os botões do menu
        navItems.forEach(i => i.classList.remove('active'));
        // Adiciona classe ativa apenas no botão clicado
        item.classList.add('active');

        // Esconde todas as telas de conteúdo
        contentViews.forEach(view => view.classList.remove('active-view'));
        
        // Pega o ID da tela alvo e mostra ela na tela
        const targetId = item.getAttribute('data-target');
        document.getElementById(targetId).classList.add('active-view');
    });
});

// 2. INTERAÇÃO DE CLIQUE NOS LIVROS (MODAL DETALHADO)
const modal = document.getElementById('bookModal');
const closeModalBtn = document.getElementById('closeModalBtn');
const bookCards = document.querySelectorAll('.book-card[data-synopsis]');

bookCards.forEach(card => {
    card.addEventListener('click', () => {
        // Coleta as informações dinâmicas de dentro do card clicado
        const title = card.querySelector('.book-title').innerText;
        const cover = card.querySelector('.book-cover').innerText;
        const synopsis = card.getAttribute('data-synopsis');

        // Aplica as informações direto dentro do Modal (Pop-up)
        document.getElementById('modalTitle').innerText = title;
        document.getElementById('modalCover').innerText = cover;
        document.getElementById('modalSynopsis').innerText = synopsis;

        // Abre o Modal com efeito fade-in
        modal.classList.add('modal-open');
    });
});

// Fechar o Modal ao clicar no 'X' ou fora da caixinha de conteúdo
closeModalBtn.addEventListener('click', () => modal.classList.remove('modal-open'));
modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.classList.remove('modal-open');
});